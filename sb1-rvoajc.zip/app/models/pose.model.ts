export interface Pose {
  id: string;
  name: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: number;
  referenceVideoUrl?: string;
  keyPoints: string[];
}

export interface PoseAttempt {
  id: string;
  poseId: string;
  timestamp: Date;
  accuracy: number;
  duration: number;
  feedback: string[];
}

export interface UserProgress {
  userId: string;
  poseId: string;
  attempts: PoseAttempt[];
  bestScore: number;
  lastPracticed: Date;
}