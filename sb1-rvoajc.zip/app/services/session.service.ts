import { Injectable } from '@nativescript/core';
import { DatabaseService } from './database.service';
import { PoseDetectionService } from './pose-detection.service';
import { Pose, PoseAttempt } from '../models/pose.model';

@Injectable()
export class SessionService {
  private currentPose: Pose | null = null;
  private sessionStartTime: Date | null = null;

  constructor(
    private database: DatabaseService,
    private poseDetection: PoseDetectionService
  ) {}

  startSession(pose: Pose): void {
    this.currentPose = pose;
    this.sessionStartTime = new Date();
  }

  endSession(): void {
    this.currentPose = null;
    this.sessionStartTime = null;
  }

  processPoseFrame(poseData: any): void {
    if (!this.currentPose || !this.sessionStartTime) {
      return;
    }

    const analysis = this.poseDetection.analyzePose(poseData);

    const attempt: PoseAttempt = {
      id: Date.now().toString(),
      poseId: this.currentPose.id,
      timestamp: new Date(),
      accuracy: analysis.accuracy,
      duration: this.calculateDuration(),
      feedback: analysis.feedback
    };

    this.database.saveAttempt(attempt);
  }

  private calculateDuration(): number {
    if (!this.sessionStartTime) return 0;
    return (new Date().getTime() - this.sessionStartTime.getTime()) / 1000;
  }
}