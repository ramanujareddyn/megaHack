import { Injectable } from '@nativescript/core';
import { Pose, PoseAttempt, UserProgress } from '../models/pose.model';

@Injectable()
export class DatabaseService {
  private poses: Map<string, Pose> = new Map();
  private attempts: Map<string, PoseAttempt[]> = new Map();
  private progress: Map<string, UserProgress[]> = new Map();

  constructor() {
    this.initializeDefaultPoses();
  }

  private initializeDefaultPoses() {
    const defaultPoses: Pose[] = [
      {
        id: '1',
        name: 'Mountain Pose',
        description: 'Basic standing pose that forms the foundation of all standing poses',
        difficulty: 'beginner',
        duration: 60,
        keyPoints: ['Stand tall', 'Feet together', 'Arms at sides']
      },
      {
        id: '2',
        name: 'Warrior I',
        description: 'Strengthening standing pose that opens the hips and chest',
        difficulty: 'intermediate',
        duration: 90,
        keyPoints: ['Front knee bent', 'Back leg straight', 'Arms reaching up']
      },
      {
        id: '3',
        name: 'Tree Pose',
        description: 'Standing balancing pose that improves focus and stability',
        difficulty: 'intermediate',
        duration: 60,
        keyPoints: ['One foot on inner thigh', 'Hips level', 'Hands at heart']
      }
    ];

    defaultPoses.forEach(pose => this.poses.set(pose.id, pose));
  }

  // Pose Methods
  getAllPoses(): Pose[] {
    return Array.from(this.poses.values());
  }

  getPoseById(id: string): Pose | undefined {
    return this.poses.get(id);
  }

  // Attempt Methods
  saveAttempt(attempt: PoseAttempt): void {
    const poseAttempts = this.attempts.get(attempt.poseId) || [];
    poseAttempts.push(attempt);
    this.attempts.set(attempt.poseId, poseAttempts);
    this.updateUserProgress(attempt);
  }

  getAttemptsByPose(poseId: string): PoseAttempt[] {
    return this.attempts.get(poseId) || [];
  }

  // Progress Methods
  private updateUserProgress(attempt: PoseAttempt): void {
    const userProgress = this.progress.get(attempt.poseId) || [];
    const existingProgress = userProgress.find(p => p.userId === 'current-user');

    if (existingProgress) {
      existingProgress.attempts.push(attempt);
      existingProgress.bestScore = Math.max(existingProgress.bestScore, attempt.accuracy);
      existingProgress.lastPracticed = new Date();
    } else {
      userProgress.push({
        userId: 'current-user',
        poseId: attempt.poseId,
        attempts: [attempt],
        bestScore: attempt.accuracy,
        lastPracticed: new Date()
      });
    }

    this.progress.set(attempt.poseId, userProgress);
  }

  getUserProgress(userId: string): UserProgress[] {
    const allProgress: UserProgress[] = [];
    this.progress.forEach(progressArray => {
      const userProgress = progressArray.find(p => p.userId === userId);
      if (userProgress) {
        allProgress.push(userProgress);
      }
    });
    return allProgress;
  }
}