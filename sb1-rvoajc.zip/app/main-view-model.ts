import { Observable } from '@nativescript/core';
import { DatabaseService } from './services/database.service';
import { SessionService } from './services/session.service';
import { Pose, UserProgress } from './models/pose.model';

export class YogaViewModel extends Observable {
  private database: DatabaseService;
  private session: SessionService;
  private _currentPose: Pose | null = null;
  private _userProgress: UserProgress[] = [];

  constructor() {
    super();
    this.database = new DatabaseService();
    this.session = new SessionService(
      this.database,
      new PoseDetectionService()
    );
    this.loadUserProgress();
  }

  get poses(): Pose[] {
    return this.database.getAllPoses();
  }

  get currentPose(): Pose | null {
    return this._currentPose;
  }

  get userProgress(): UserProgress[] {
    return this._userProgress;
  }

  selectPose(poseId: string): void {
    const pose = this.database.getPoseById(poseId);
    if (pose) {
      this._currentPose = pose;
      this.session.startSession(pose);
      this.notifyPropertyChange('currentPose', pose);
    }
  }

  endPoseSession(): void {
    this.session.endSession();
    this._currentPose = null;
    this.notifyPropertyChange('currentPose', null);
    this.loadUserProgress();
  }

  private loadUserProgress(): void {
    this._userProgress = this.database.getUserProgress('current-user');
    this.notifyPropertyChange('userProgress', this._userProgress);
  }
}